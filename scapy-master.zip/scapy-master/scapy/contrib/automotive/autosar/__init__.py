# SPDX-License-Identifier: GPL-2.0-only
# This file is part of Scapy
# See https://scapy.net/ for more information
# Copyright (C) Damian Zaręba <damianzrb@zohomail.eu>

# scapy.contrib.status = skip

"""
Package of contrib automotive AUTOSAR modules
that have to be loaded explicitly.
"""
